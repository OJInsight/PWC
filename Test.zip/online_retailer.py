
import json
import glob
from itertools import chain
import os
import pandas as pd
import duckdb
from query_code import task

def merge_data(path):
    """
    This functions takes a path and read all json files in that path and return a single merge of the files
    """
    
    combined_json = []
    for json_file in glob.glob(path +"/*.json"):
        with open(json_file, "rb") as infile:
            combined_json.append(json.load(infile))
   
    return combined_json


def generate_parquet(combined_json):
    """
    This functions takes a list of lists of dictionaries and generate a parquet file based on distinct date. Each
    parquet file is stored in a folder for that particular date, and all stored in a parent folder called parqeut output
    """

    file_dir = os.path.abspath(os.getcwd()) +'/parquet_output'
    if not os.path.exists(file_dir):
        os.makedirs(os.path.abspath(file_dir))
    df = pd.json_normalize(list(chain.from_iterable(combined_json)), record_path=['attributes'], meta=['ORDERNUMBER', 'PRODUCTCODE'])
    df['ORDERDATE']= pd.to_datetime(df['ORDERDATE'])
    distinct_date =  set(df['ORDERDATE'].to_list())
    for date in distinct_date:
        file_dir = os.path.abspath(os.getcwd()) +'/parquet_output'+ '/' +str(date.date())
        parquet_file = file_dir + '/' + str(date.date()) + '.parquet'
        if not os.path.exists(file_dir):
            os.makedirs(os.path.abspath(file_dir))
        df_date = df[df['ORDERDATE'] == date]
        df_date.to_parquet(parquet_file)

    return True
    
def analysis_query_data(combined_json, query_code, task_id, task_description): 
    """
    This functions takes a list of lists of dictionaries, a query, task id and task
    descriptions, queries the dataframe and returns an output"
    
    """
    print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>> \n')
    print("generating output for {}".format(task_id))
    print('{}'.format(task_description))
    df = pd.json_normalize(list(chain.from_iterable(combined_json)), record_path=['attributes'], meta=['ORDERNUMBER', 'PRODUCTCODE'])
    df['ORDERDATE']= pd.to_datetime(df['ORDERDATE'])
    df['month_year'] = df['ORDERDATE'].dt.strftime('%Y-%m')
    df['year'] = df['ORDERDATE'].dt.strftime('%Y')
    final_output = duckdb.query(query_code).df()
    print(final_output)
    print("output for {} generated \n".format(task_id))
    return final_output




if __name__ == "__main__":
    combined_files = merge_data(path ='dataset')
    generate_parquet(combined_json=combined_files)
    for key, value in task.items():
        analysis_query_data(combined_json=combined_files, query_code=value[0], task_id= key, task_description=value[1])