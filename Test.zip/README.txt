Description
------------
This outline provides the ETL pipeline, to process the json files and draw insight from the data.
	
The purpose of the pipelines is to answer the business questions,the total value of cancelled/on hold orders, 
number of unique products per product line, product discount and Sales trend on classic cars.


ETL Pipeline
------------
For the ETL pipeline, Python and SQL is used as it contains libraries such as pandas,glob,duckdb 
that simplifies data manipulation and transformation. 

There are 3 json data files involved, which contains information about online retail product sales, 
which was merged and loaded into daily partitions in Parquet format


The ETL process consists of three functions(merge_data, generate_parquet and analysis_query_data) which manipulate and
transformation query that analyse business requests



Running the ETL Pipeline
------------
Run online_retailer.py to generate daily files in Parquet format, If files were created previously, they will be dropped and recreated.
The pipeline will also outputs some analysis and computes products discount as requeted from the business.

Note: The online_retailer.py call query_code.py, so no need to execute query_code.py separately.
