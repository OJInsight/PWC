task = {'task 1':[""" SELECT year AS ORDERYEAR, status,  
                             sum(sales) AS TOTALVALUE
                      FROM df
                      WHERE status = 'Cancelled' OR status = 'On Hold'
                      GROUP BY year ,status""", "Total value of cancelled orders and orders currently on hold by year."],

        'task 2':[""" SELECT productline, 
                             count(distinct productcode) AS NUMBEROFPRODUCT
                      FROM df
                      GROUP BY productline;""", "Number of unique products per product line"],

        'task 3':[""" SELECT month_year AS MONTH_YEAR,
                             sum(quantityordered) AS QUANTITYORDERED,
                             sum(sales) AS SALES,
                             sum(sales) - LAG(sum(sales)) OVER (ORDER BY month_year ASC) AS SALES_GROWTH
                      FROM df
                      WHERE productline = 'Classic Cars' AND status='Shipped'
                      GROUP BY month_year;""", "Sales trend in the number of classic cars they’ve shipped"],
        
        'task 4':[""" SELECT quantityordered,priceeach,sales,orderdate,productline,msrp,
                         CASE WHEN productline in('Vintage Cars','Classic Cars','Motorcycles','Trucks and Buses') THEN
                              CASE WHEN quantityordered <=30 THEN msrp 
                                   WHEN quantityordered between 30 and 60 THEN round((msrp-0.025*msrp),1)
                                   WHEN quantityordered between 60 and 80 THEN round((msrp-0.04*msrp),1)
                                   WHEN quantityordered between 80 and 100 THEN round((msrp-0.06*msrp),1)
                                   WHEN quantityordered >100 THEN round((msrp-0.1*msrp),1)
                                   ELSE msrp
                              END
                           ELSE msrp
                         END MSRPDISCOUNTEDPRICE
                      FROM df;""", "Bulk discounts against the MSRP for vintage or classic cars, motorbikes, trucks and buses"],

}
